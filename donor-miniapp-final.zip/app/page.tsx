"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import Image from "next/image";
import donorImg from "/public/DONOR_icon.png";
import roadmapImg from "/public/DONOR_roadmap.png";

export default function DonorMiniAppFinal() {
  const phases = [
    { title: "Phase 1", subtitle: "Donor & Blood", status: "LIVE" },
    { title: "Phase 2", subtitle: "Mint NFT", status: "Coming Soon" },
    { title: "Phase 3", subtitle: "Staking Baseblood", status: "Coming Soon" },
  ];

  const contractAddress = "0x28965740ff1e15cf39bccf2f861265636bc6db07";
  const etherscanLink = `https://etherscan.io/address/${contractAddress}`;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} viewport={{ once: true }}>
        <Card className="rounded-2xl shadow-md bg-black border-red-700">
          <CardContent className="p-5 text-white text-center">
            <Image src={donorImg} alt="DONOR Logo" width={100} height={100} className="mx-auto mb-4" />
            <p className="text-lg mb-3">Welcome to the DONOR ecosystem. Strengthen the network, expand the community.</p>
            <div className="flex flex-col gap-2">
              <Button className="bg-red-600 hover:bg-red-700">Share</Button>
              <Button variant="outline" className="border border-white text-white" onClick={() => window.open(etherscanLink, "_blank")}>
                View Smart Contract
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.2 }} viewport={{ once: true }}>
        <Card className="rounded-2xl shadow-md bg-black border-red-700">
          <CardContent className="p-5 text-white">
            <h2 className="text-xl font-bold mb-4 text-center">🚀 Roadmap</h2>
            <div className="flex flex-col space-y-4">
              {phases.map((phase, idx) => (
                <div key={idx} className={`p-3 rounded-xl border ${phase.status === "LIVE" ? "border-red-600 bg-red-900/20" : "border-gray-700 bg-gray-900/20"}`}>
                  <h3 className="font-semibold">{phase.title}</h3>
                  <p className="text-sm mb-1">{phase.subtitle}</p>
                  <span className={`text-xs px-2 py-1 rounded-full ${phase.status === "LIVE" ? "bg-red-600 text-white" : "bg-gray-700 text-gray-300"}`}>
                    {phase.status}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-4 text-center">
              <p className="text-sm text-muted-foreground">Phases 2 & 3 will be available soon. Stay tuned!</p>
            </div>
            <div className="mt-4 flex justify-center">
              <Image src={roadmapImg} alt="DONOR Roadmap Visual" width={300} height={300} className="rounded-xl shadow-md" />
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}