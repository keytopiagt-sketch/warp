import React from 'react';
export const Card = ({ children, className }: any) => (
  <div className={`p-2 rounded-xl ${className}`}>{children}</div>
);
export const CardContent = ({ children, className }: any) => (
  <div className={`${className}`}>{children}</div>
);