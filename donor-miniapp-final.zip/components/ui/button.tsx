import React from 'react';
export const Button = ({ children, className, variant, ...props }: any) => (
  <button className={`${className} ${variant === 'outline' ? 'border border-white text-white' : ''}`} {...props}>
    {children}
  </button>
);